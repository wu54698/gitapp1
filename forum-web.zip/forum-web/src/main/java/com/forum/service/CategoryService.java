package com.forum.service;

import com.forum.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Service
public interface CategoryService extends JpaRepository<Category, Integer> {
}
