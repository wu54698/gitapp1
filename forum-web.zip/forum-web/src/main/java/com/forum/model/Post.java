package com.forum.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "post")
@Data
public class Post {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "title")
	private String title ;
	
	@Column(name = "body")
	private String body ;

	@Column(name = "time")
	private Date time ;

	@Column(name = "isOP")
	private boolean isOP ;

	@ManyToOne
	@JoinColumn(name = "memberId")
	private ForumMember member;
	
	@ManyToOne
	@JoinColumn(name = "threadId")
	private Thread thread;

}
